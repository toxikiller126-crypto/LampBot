
require('dotenv').config();

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: "1440800524117999666",
  guildId: "1353388915888754728",
  botInvite: "https://discord.com/api/oauth2/authorize?client_id=1440800524117999666&permissions=8&scope=bot%20applications.commands",
  serverInvite: "https://discord.gg/9aj37ET6Rj",
  
  presence: {
    status: 'online',
    activities: [
      {
        name: '{servers} servers',
        type: 3
      }
    ]
  }
};
  