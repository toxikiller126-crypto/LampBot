const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Start a new giveaway')
    .addStringOption(option =>
      option.setName('prize')
        .setDescription('What are you giving away?')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('duration')
        .setDescription('Duration number')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('unit')
        .setDescription('Time unit')
        .setRequired(true)
        .addChoices(
          { name: 'Seconds', value: 's' },
          { name: 'Minutes', value: 'm' },
          { name: 'Hours', value: 'h' },
          { name: 'Days', value: 'd' }
        ))
    .addIntegerOption(option =>
      option.setName('winners')
        .setDescription('Number of winners (1-20)')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(20))
    .addChannelOption(option =>
      option.setName('channel')
        .setDescription('Channel to host giveaway in')),

  async execute(interaction) {
    // Permission check
    if (!interaction.member.permissions.has('ManageMessages')) {
      return interaction.reply({ 
        content: '❌ You need **Manage Messages** permission to start giveaways!',
        ephemeral: true 
      });
    }

    const prize = interaction.options.getString('prize');
    const duration = interaction.options.getInteger('duration');
    const unit = interaction.options.getString('unit');
    const winners = interaction.options.getInteger('winners');
    const channel = interaction.options.getChannel('channel') || interaction.channel;

    // Validate duration limits
    if (unit === 's' && (duration < 1 || duration > 60)) {
      return interaction.reply({ 
        content: '❌ Seconds must be between 1 and 60!',
        ephemeral: true 
      });
    }
    if (unit === 'm' && (duration < 1 || duration > 60)) {
      return interaction.reply({ 
        content: '❌ Minutes must be between 1 and 60!',
        ephemeral: true 
      });
    }
    if (unit === 'h' && (duration < 1 || duration > 24)) {
      return interaction.reply({ 
        content: '❌ Hours must be between 1 and 24!',
        ephemeral: true 
      });
    }
    if (unit === 'd' && (duration < 1 || duration > 365)) {
      return interaction.reply({ 
        content: '❌ Days must be between 1 and 365!',
        ephemeral: true 
      });
    }

    // Convert duration to milliseconds and text
    const durationMs = parseDuration(duration, unit);
    const durationText = getDurationText(duration, unit);

    // Create giveaway embed
    const giveawayEmbed = new EmbedBuilder()
      .setColor(0x00FF00)
      .setTitle('🎉 **GIVEAWAY** 🎉')
      .setDescription(`**Prize:** ${prize}\n**Winners:** ${winners}\n**Duration:** ${durationText}\n\nReact with 🎉 to enter!`)
      .setFooter({ text: `Hosted by ${interaction.user.tag}` })
      .setTimestamp(Date.now() + durationMs);

    try {
      const message = await channel.send({ embeds: [giveawayEmbed] });
      await message.react('🎉');

      await interaction.reply({ 
        content: `✅ Giveaway started in ${channel}! Ends in ${durationText}`, 
        ephemeral: true 
      });

      // Schedule end
      setTimeout(async () => {
        await endGiveaway(message, prize, winners);
      }, durationMs);

    } catch (error) {
      console.error(error);
      await interaction.reply({ 
        content: '❌ Failed to start giveaway!', 
        ephemeral: true 
      });
    }
  },
};

// Duration parser function
function parseDuration(value, unit) {
  switch (unit) {
    case 's': return value * 1000; // seconds to milliseconds
    case 'm': return value * 60 * 1000; // minutes to milliseconds
    case 'h': return value * 60 * 60 * 1000; // hours to milliseconds
    case 'd': return value * 24 * 60 * 60 * 1000; // days to milliseconds
    default: return 60 * 1000; // default 1 minute
  }
}

// Duration text formatter
function getDurationText(value, unit) {
  switch (unit) {
    case 's': return `${value} second${value > 1 ? 's' : ''}`;
    case 'm': return `${value} minute${value > 1 ? 's' : ''}`;
    case 'h': return `${value} hour${value > 1 ? 's' : ''}`;
    case 'd': return `${value} day${value > 1 ? 's' : ''}`;
    default: return `${value} minute${value > 1 ? 's' : ''}`;
  }
}

// End giveaway function
async function endGiveaway(message, prize, winners) {
  try {
    const reaction = message.reactions.cache.get('🎉');
    if (!reaction) return;

    const users = await reaction.users.fetch();
    const participants = users.filter(user => !user.bot).map(user => user.id);

    if (participants.length === 0) {
      const endedEmbed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('🎉 **GIVEAWAY ENDED** 🎉')
        .setDescription(`**Prize:** ${prize}\n**Winners:** No participants!\n\n**Giveaway ended with no entries!**`)
        .setFooter({ text: 'Giveaway ended' })
        .setTimestamp();

      return message.edit({ embeds: [endedEmbed] });
    }

    // Select winners
    const shuffled = [...participants].sort(() => 0.5 - Math.random());
    const selectedWinners = shuffled.slice(0, winners);
    const winnerMentions = selectedWinners.map(id => `<@${id}>`).join(', ');

    // Update giveaway message
    const endedEmbed = new EmbedBuilder()
      .setColor(0xFFA500)
      .setTitle('🎉 **GIVEAWAY ENDED** 🎉')
      .setDescription(`**Prize:** ${prize}\n**Winners:** ${winnerMentions}\n**Participants:** ${participants.length}\n\nCongratulations to the winners!`)
      .setFooter({ text: 'Giveaway ended' })
      .setTimestamp();

    await message.edit({ embeds: [endedEmbed] });

    // Announce winners
    await message.channel.send({
      content: `🎉 **Congratulations** ${winnerMentions}! You won **${prize}**!\n\n🔗 [Jump to Giveaway](${message.url})`
    });

  } catch (error) {
    console.error('Giveaway error:', error);
  }
}