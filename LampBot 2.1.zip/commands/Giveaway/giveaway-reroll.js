const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway-reroll')
    .setDescription('Reroll winners for a giveaway')
    .addStringOption(option =>
      option.setName('message_id')
        .setDescription('Message ID of the giveaway to reroll')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('winners')
        .setDescription('Number of winners to select (1-20)')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(20)),

  async execute(interaction) {
    // Permission check
    if (!interaction.member.permissions.has('ManageMessages')) {
      return interaction.reply({ 
        content: '❌ You need **Manage Messages** permission to reroll giveaways!',
        ephemeral: true 
      });
    }

    const messageId = interaction.options.getString('message_id');
    const winnersCount = interaction.options.getInteger('winners');

    try {
      // Fetch the giveaway message
      const message = await interaction.channel.messages.fetch(messageId);
      
      // Check if it's a giveaway message
      const reaction = message.reactions.cache.get('🎉');
      if (!reaction) {
        return interaction.reply({ 
          content: '❌ No giveaway found with that message ID!',
          ephemeral: true 
        });
      }

      // Fetch participants
      const users = await reaction.users.fetch();
      const participants = users.filter(user => !user.bot).map(user => user.id);

      if (participants.length === 0) {
        return interaction.reply({ 
          content: '❌ No participants found to reroll!',
          ephemeral: true 
        });
      }

      if (participants.length < winnersCount) {
        return interaction.reply({ 
          content: `❌ Not enough participants! Only ${participants.length} participants but you want ${winnersCount} winners.`,
          ephemeral: true 
        });
      }

      // Select new winners
      const shuffled = [...participants].sort(() => 0.5 - Math.random());
      const newWinners = shuffled.slice(0, winnersCount);
      const winnerMentions = newWinners.map(id => `<@${id}>`).join(', ');

      // Create reroll embed
      const rerollEmbed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('🎉 **GIVEAWAY REROLL** 🎉')
        .setDescription(`**New Winners:** ${winnerMentions}\n**Total Participants:** ${participants.length}\n\nCongratulations to the new winners!`)
        .setFooter({ text: `Rerolled by ${interaction.user.tag}` })
        .setTimestamp();

      await interaction.reply({ 
        content: `🎉 Successfully rerolled ${winnersCount} winner(s)!`,
        embeds: [rerollEmbed] 
      });

      // Also send in the original giveaway channel
      await message.channel.send({
        content: `🎉 **REROLL RESULTS**\n${winnerMentions} - You won the reroll! 🔄`
      });

    } catch (error) {
      console.error('Reroll error:', error);
      await interaction.reply({ 
        content: '❌ Invalid message ID or message not found in this channel!',
        ephemeral: true 
      });
    }
  },
};