const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
module.exports = {
  data: new SlashCommandBuilder().setName('autorole-set').setDescription('Set autorole').addRoleOption(o=>o.setName('role').setDescription('Role to add').setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),
  async execute(interaction) {
    const role = interaction.options.getRole('role');
    const db = JSON.parse(fs.readFileSync('./database/autorole.json','utf8'));
    db.roleId = role.id;
    fs.writeFileSync('./database/autorole.json', JSON.stringify(db, null, 2));
    interaction.reply({ content: `Autorole set to ${role.name}` });
  }
};