const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
module.exports = {
  data: new SlashCommandBuilder().setName('autorole-remove').setDescription('Remove autorole').setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),
  async execute(interaction) {
    const db = JSON.parse(fs.readFileSync('./database/autorole.json','utf8'));
    db.roleId = null;
    fs.writeFileSync('./database/autorole.json', JSON.stringify(db, null, 2));
    interaction.reply({ content: 'Autorole removed.' });
  }
};