const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('userinfo').setDescription('Get user info').addUserOption(o=>o.setName('user').setDescription('User')),
  async execute(interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const member = await interaction.guild.members.fetch(user.id).catch(()=>null);
    const embed = {
      title: `${user.tag}`,
      fields: [
        { name: 'ID', value: user.id, inline: true },
        { name: 'Joined', value: member ? new Date(member.joinedTimestamp).toLocaleString() : 'N/A', inline: true }
      ],
      thumbnail: { url: user.displayAvatarURL() }
    };
    interaction.reply({ embeds: [embed] });
  }
};