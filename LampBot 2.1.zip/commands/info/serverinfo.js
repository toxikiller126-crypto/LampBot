const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('Get detailed server information'),

  async execute(interaction) {
    const guild = interaction.guild;
    const owner = await guild.fetchOwner();

    // Server boost info
    const boostLevel = guild.premiumTier;
    const boostCount = guild.premiumSubscriptionCount;
    
    // Member stats
    const members = guild.memberCount;
    const bots = guild.members.cache.filter(m => m.user.bot).size;
    const humans = members - bots;
    
    // Channel stats
    const textChannels = guild.channels.cache.filter(c => c.type === 0).size;
    const voiceChannels = guild.channels.cache.filter(c => c.type === 2).size;
    const categories = guild.channels.cache.filter(c => c.type === 4).size;

    const embed = new EmbedBuilder()
      .setColor(0x0099FF)
      .setTitle(`📊 ${guild.name} - Server Information`)
      .setThumbnail(guild.iconURL({ dynamic: true, size: 512 }))
      .addFields(
        {
          name: '🆔 Server ID',
          value: `\`${guild.id}\``,
          inline: true
        },
        {
          name: '👑 Owner',
          value: `${owner.user.tag}`,
          inline: true
        },
        {
          name: '📅 Created',
          value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`,
          inline: true
        },
        {
          name: '👥 Members',
          value: `**Total:** ${members}\n**Humans:** ${humans}\n**Bots:** ${bots}`,
          inline: true
        },
        {
          name: '📁 Channels',
          value: `**Text:** ${textChannels}\n**Voice:** ${voiceChannels}\n**Categories:** ${categories}`,
          inline: true
        },
        {
          name: '🎨 Server Features',
          value: guild.features.length > 0 
            ? guild.features.map(f => `• ${f}`).join('\n')
            : 'No special features',
          inline: false
        },
        {
          name: '🚀 Boost Status',
          value: `**Level:** ${boostLevel}\n**Boosts:** ${boostCount || 0}`,
          inline: true
        },
        {
          name: '🔐 Verification',
          value: `**Level:** ${guild.verificationLevel}`,
          inline: true
        },
        {
          name: '😄 Emojis & Stickers',
          value: `**Emojis:** ${guild.emojis.cache.size}\n**Stickers:** ${guild.stickers.cache.size}`,
          inline: true
        }
      )
      .setFooter({ 
        text: `Requested by ${interaction.user.tag}`, 
        iconURL: interaction.user.displayAvatarURL({ dynamic: true }) 
      })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};