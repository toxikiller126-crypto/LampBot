const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('invite')
    .setDescription('Get bot invite links'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x00FF00)
      .setTitle('🔗 Invite Links')
      .setDescription('Add me to your server or join our support community!')
      .addFields(
        {
          name: '🤖 Bot Invite',
          value: '[Click here to add bot](https://discord.com/oauth2/authorize?client_id=1440800524117999666&permissions=8&scope=bot%20applications.commands)',
          inline: true
        },
        {
          name: '🛠️ Support Server',
          value: '[Click to join server](https://discord.gg/9aj37ET6Rj)',
          inline: true
        },
        {
          name: '📊 Permissions',
          value: '```Administrator (Recommended)```',
          inline: false
        }
      )
      .setFooter({ text: 'Thank you for using our bot! ❤️' })
      .setTimestamp();

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setLabel('Add to Server')
          .setStyle(ButtonStyle.Link)
          .setURL('https://discord.com/oauth2/authorize?client_id=1440800524117999666&permissions=8&scope=bot%20applications.commands'),
        new ButtonBuilder()
          .setLabel('Support Server')
          .setStyle(ButtonStyle.Link)
          .setURL('https://discord.gg/9aj37ET6Rj'),
        new ButtonBuilder()
          .setLabel('Instagram')
          .setStyle(ButtonStyle.Link)
          .setURL('https://www.instagram.com/mr.lampgaming?igsh=MTZpNDIzZ3dmdHdsNQ==')
      );

    await interaction.reply({ 
      embeds: [embed],
      components: [row]
    });
  },
};