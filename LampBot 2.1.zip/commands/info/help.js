const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Get help with all bot commands'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('🎮 Bot Commands & Help')
      .setDescription('Here are all available commands organized by categories:')
      .addFields(
        {
          name: '📊 **Info Commands**',
          value: '```\n/serverinfo - Detailed server information\n/userinfo [user] - User profile information\n/avatar [user] - Get user avatar\n/invite - Get bot and server invite links\n```',
          inline: false
        },
        {
          name: '🛡️ **Security & Verification**',
          value: '```\n/verify setup - Setup verification system\n/verify role @role - Set verification role\n/captcha enable - Enable captcha verification\n```',
          inline: false
        },
        {
          name: '📈 **Tracking & Counting**',
          value: '```\n/invitetracker setup - Track invites\n/counting setup - Setup counting channel\n/stats - View server statistics\n```',
          inline: false
        },
        {
          name: '🔔 **Notifications**',
          value: '```\n/notify youtube [channel_id] - YouTube notifications\n/notify instagram [username] - Instagram notifications\n/notify setup - Setup notification channel\n```',
          inline: false
        },
        {
          name: '💬 **Utility Commands**',
          value: '```\n/say [message] - Make bot say something\n/embed [title] [description] - Create embed\n/poll [question] - Create a poll\n/clear [amount] - Delete messages\n```',
          inline: false
        },
        {
          name: '🎯 **Level & XP**',
          value: '```\n/level [user] - Check level\n/leaderboard - Server rankings\n/rank - Detailed rank card\n```',
          inline: false
        }
      )
      .setFooter({ text: 'Use /command-name for more info about specific commands' })
      .setTimestamp();

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setLabel('🤖 Invite Bot')
          .setStyle(ButtonStyle.Link)
          .setURL('https://discord.com/oauth2/authorize?client_id=1440800524117999666&permissions=8&scope=bot%20applications.commands'),
        new ButtonBuilder()
          .setLabel('🛠️ Support Server')
          .setStyle(ButtonStyle.Link)
          .setURL('https://discord.gg/9aj37ET6Rj'),
        new ButtonBuilder()
          .setLabel('📚 Documentation')
          .setStyle(ButtonStyle.Link)
          .setURL('https://github.com/your-bot-docs')
      );

    await interaction.reply({ 
      embeds: [embed],
      components: [row]
    });
  },
};