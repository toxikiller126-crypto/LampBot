const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Check bot latency and status'),
    
  async execute(interaction) {
    const start = Date.now();
    
    const embed = new EmbedBuilder()
      .setColor(0x00FF00)
      .setTitle('🏓 Pong!')
      .setDescription('Bot is working perfectly!')
      .addFields(
        { name: '📡 WebSocket Ping', value: `${interaction.client.ws.ping}ms`, inline: true },
        { name: '⚡ Response Time', value: `${Date.now() - start}ms`, inline: true },
        { name: '🖥️ Servers', value: `${interaction.client.guilds.cache.size}`, inline: true },
        { name: '👥 Users', value: `${interaction.client.users.cache.size}`, inline: true },
        { name: '📊 Commands', value: `${interaction.client.commands.size}`, inline: true }
      )
      .setFooter({ text: 'Bot is fully operational' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};