const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('level-setup')
    .setDescription('Configure the level system like Arcane')
    .addSubcommand(subcommand =>
      subcommand
        .setName('enable')
        .setDescription('Enable level system')
        .addChannelOption(option =>
          option.setName('channel')
            .setDescription('Level up announcement channel')
            .addChannelTypes(ChannelType.GuildText))
        .addStringOption(option =>
          option.setName('message')
            .setDescription('Custom level up message (use {user} {level} {xp})')))
    .addSubcommand(subcommand =>
      subcommand
        .setName('disable')
        .setDescription('Disable level system'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('settings')
        .setDescription('View current level settings'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();

    if (subcommand === 'enable') {
      const channel = interaction.options.getChannel('channel');
      const customMessage = interaction.options.getString('message') || '🎉 {user} reached level **{level}**! Keep going! 🚀';

      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle('✅ Level System Enabled')
        .setDescription('Arcane-style level system is now active!')
        .addFields(
          { name: '📊 Level Up Channel', value: channel ? channel.toString() : '📝 Current Channel', inline: true },
          { name: '⭐ XP Range', value: '15-25 XP/message', inline: true },
          { name: '⏰ Cooldown', value: '60 seconds', inline: true },
          { name: '💬 Level Up Message', value: `\`\`\`${customMessage}\`\`\``, inline: false }
        )
        .setFooter({ text: 'Users will earn XP for active participation' })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });

    } else if (subcommand === 'disable') {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('❌ Level System Disabled')
        .setDescription('Level system has been turned off. Users will no longer earn XP.')
        .setFooter({ text: 'You can enable it again anytime' })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });

    } else if (subcommand === 'settings') {
      const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('⚙️ Level System Settings')
        .setDescription('Current configuration for level system')
        .addFields(
          { name: '📊 Status', value: '✅ **Enabled**', inline: true },
          { name: '📢 Announcement Channel', value: '📝 Current Channel', inline: true },
          { name: '⭐ XP per Message', value: '15-25 XP', inline: true },
          { name: '⏰ Cooldown', value: '60 seconds', inline: true },
          { name: '📈 Level Formula', value: '`5 * (Level^2) + 50 * Level + 100`', inline: false },
          { name: '💬 Level Up Message', value: '🎉 {user} reached level **{level}**! Keep going! 🚀', inline: false }
        )
        .setFooter({ text: 'Use /level-help for more information' })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });
    }
  },
};