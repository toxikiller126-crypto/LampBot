const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('level-help')
    .setDescription('Learn everything about the level system'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('🎮 Arcane-Style Level System Help')
      .setDescription('Complete guide to our advanced leveling system!')
      .addFields(
        {
          name: '📊 **Basic Commands**',
          value: '```\n/level [user] - Check your/someone\'s level\n/leaderboard - View server rankings\n/rank - Detailed rank card\n/level-setup - Configure system (Admin)\n```',
          inline: false
        },
        {
          name: '⭐ **How to Earn XP**',
          value: '```\n💬 Sending Messages: 15-25 XP\n⏰ Cooldown: 60 seconds\n📝 Minimum Length: 3 characters\n🚫 No Spam: Same message won\'t count\n```',
          inline: false
        },
        {
          name: '📈 **Level Requirements**',
          value: '```\nLevel 1: 100 XP\nLevel 5: 1,000 XP\nLevel 10: 3,000 XP\nLevel 20: 12,000 XP\nLevel 50: 75,000 XP\n```',
          inline: false
        },
        {
          name: '🔧 **Setup Variables**',
          value: '```\n{user} - User mention\n{username} - Username\n{level} - New level\n{xp} - Current XP\n{server} - Server name\n{memberCount} - Server member count\n```',
          inline: false
        },
        {
          name: '💬 **Message Examples**',
          value: '```\nDefault: "🎉 {user} reached level {level}! 🚀"\nCustom: "🔥 {username} leveled up to {level}! {server} proud!"\nAdvanced: "🎊 {user} is now level {level} with {xp} XP! #{memberCount}"\n```',
          inline: false
        },
        {
          name: '⚙️ **Admin Commands**',
          value: '```\n/level-setup enable - Turn on system\n/level-setup disable - Turn off system\n/level-setup settings - View settings\n\nOptions:\n• channel: Set announcement channel\n• message: Custom level up message\n```',
          inline: false
        }
      )
      .setFooter({ text: 'Need more help? Contact server staff' })
      .setTimestamp();

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setLabel('Quick Setup')
          .setStyle(ButtonStyle.Primary)
          .setCustomId('quick_setup'),
        new ButtonBuilder()
          .setLabel('Message Examples')
          .setStyle(ButtonStyle.Secondary)
          .setCustomId('message_examples'),
        new ButtonBuilder()
          .setLabel('Variables Guide')
          .setStyle(ButtonStyle.Success)
          .setCustomId('variables_guide')
      );

    await interaction.reply({ 
      embeds: [embed],
      components: [row]
    });
  },
};