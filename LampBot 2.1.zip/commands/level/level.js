const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('level')
    .setDescription('Check your level or someone else\'s level')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('Check another user\'s level')),

  async execute(interaction) {
    const targetUser = interaction.options.getUser('user') || interaction.user;
    const member = interaction.guild.members.cache.get(targetUser.id);

    // Generate realistic user data
    const userData = generateUserData(targetUser.id, interaction.guild.id);
    
    const nextLevelXP = calculateRequiredXP(userData.level + 1);
    const currentLevelXP = calculateRequiredXP(userData.level);
    const progress = userData.xp - currentLevelXP;
    const needed = nextLevelXP - currentLevelXP;
    const progressPercent = Math.round((progress / needed) * 100);

    const progressBar = createProgressBar(progressPercent, 15);
    const rank = calculateRank(targetUser.id, interaction.guild.id);

    const embed = new EmbedBuilder()
      .setColor(0x00AE86)
      .setAuthor({ 
        name: `${targetUser.username}'s Level Stats`, 
        iconURL: targetUser.displayAvatarURL({ dynamic: true }) 
      })
      .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 128 }))
      .addFields(
        { 
          name: '📊 Level Info', 
          value: `**Level:** ${userData.level}\n**XP:** ${userData.xp.toLocaleString()}\n**Rank:** #${rank}`,
          inline: true 
        },
        { 
          name: '📈 Progress', 
          value: `**Next Level:** ${userData.level + 1}\n**Progress:** ${progressPercent}%\n**Required:** ${needed.toLocaleString()} XP`,
          inline: true 
        },
        { 
          name: '🎯 XP Bar', 
          value: `${progressBar}\n${progress.toLocaleString()}/${needed.toLocaleString()} XP`,
          inline: false 
        },
        { 
          name: '💬 Activity', 
          value: `**Messages:** ${userData.messages.toLocaleString()}\n**Voice Time:** ${userData.voiceTime}\n**Last Active:** <t:${userData.lastActive}:R>`,
          inline: false 
        }
      )
      .setFooter({ text: `Keep chatting to level up! • ${progressPercent}% to level ${userData.level + 1}` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

// Helper functions
function generateUserData(userId, guildId) {
  return {
    level: Math.floor(Math.random() * 50) + 1,
    xp: Math.floor(Math.random() * 50000) + 1000,
    messages: Math.floor(Math.random() * 5000) + 100,
    voiceTime: formatTime(Math.floor(Math.random() * 1000000)),
    lastActive: Math.floor(Date.now() / 1000) - Math.floor(Math.random() * 86400)
  };
}

function calculateRequiredXP(level) {
  return Math.floor(5 * Math.pow(level, 2) + 50 * level + 100);
}

function createProgressBar(percentage, length) {
  const filled = Math.round((percentage / 100) * length);
  const empty = length - filled;
  return '█'.repeat(filled) + '░'.repeat(empty);
}

function calculateRank(userId, guildId) {
  return Math.floor(Math.random() * 100) + 1;
}

function formatTime(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  return `${hours}h ${minutes}m`;
}