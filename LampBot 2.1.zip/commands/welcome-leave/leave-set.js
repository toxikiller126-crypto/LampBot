const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
module.exports = {
  data: new SlashCommandBuilder().setName('leave-set').setDescription('Set leave channel and message').addChannelOption(o=>o.setName('channel').setDescription('Channel').setRequired(true)).addStringOption(o=>o.setName('message').setDescription('Message').setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(interaction) {
    const ch = interaction.options.getChannel('channel');
    const msg = interaction.options.getString('message');
    const db = JSON.parse(fs.readFileSync('./database/leave.json','utf8'));
    db.channel = ch.id;
    db.message = msg;
    fs.writeFileSync('./database/leave.json', JSON.stringify(db, null, 2));
    interaction.reply({ content: 'Leave saved.' });
  }
};