const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
module.exports = {
  data: new SlashCommandBuilder().setName('leave-test').setDescription('Test leave message'),
  async execute(interaction) {
    const db = JSON.parse(fs.readFileSync('./database/leave.json','utf8'));
    if (!db.channel) return interaction.reply({ content: 'Leave not configured.', ephemeral: true });
    const ch = interaction.guild.channels.cache.get(db.channel);
    if (!ch) return interaction.reply({ content: 'Channel not found.', ephemeral: true });
    ch.send({ content: db.message.replace('{user}', `${interaction.user.tag}`).replace('{guild}', interaction.guild.name) });
    interaction.reply({ content: 'Test sent.', ephemeral: true });
  }
};