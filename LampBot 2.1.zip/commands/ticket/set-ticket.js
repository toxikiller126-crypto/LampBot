const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('set-ticket')
    .setDescription('Setup ticket system for your server')
    .addStringOption(option =>
      option.setName('title')
        .setDescription('Title for ticket embed')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('description')
        .setDescription('Description for ticket embed')
        .setRequired(true))
    .addChannelOption(option =>
      option.setName('channel')
        .setDescription('Channel where ticket panel will be sent')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true))
    .addRoleOption(option =>
      option.setName('staff_role')
        .setDescription('Staff role that can manage tickets')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('button_text')
        .setDescription('Button text (default: Create Ticket)')
        .setRequired(false))
    .addStringOption(option =>
      option.setName('button_emoji')
        .setDescription('Button emoji (default: 🎫)')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const title = interaction.options.getString('title');
    const description = interaction.options.getString('description');
    const channel = interaction.options.getChannel('channel');
    const staffRole = interaction.options.getRole('staff_role');
    const buttonText = interaction.options.getString('button_text') || 'Create Ticket';
    const buttonEmoji = interaction.options.getString('button_emoji') || '🎫';

    // Check permissions
    if (!channel.permissionsFor(interaction.guild.members.me).has(['ViewChannel', 'SendMessages', 'EmbedLinks'])) {
      return interaction.reply({ 
        content: '❌ I don\'t have permission to send messages/embeds in that channel!', 
        ephemeral: true 
      });
    }

    try {
      // Create ticket embed
      const ticketEmbed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle(title)
        .setDescription(description)
        .addFields(
          { 
            name: '📋 How to Create a Ticket', 
            value: '1. Click the button below\n2. A private ticket channel will be created\n3. Explain your issue to the staff team\n4. Wait for staff response', 
            inline: false 
          },
          { 
            name: '🛠️ Support Team', 
            value: `${staffRole}`, 
            inline: true 
          },
          { 
            name: '⏰ Response Time', 
            value: 'Usually within 24 hours', 
            inline: true 
          }
        )
        .setFooter({ text: `${interaction.guild.name} Support System` })
        .setTimestamp();

      // Create ticket button
      const ticketButton = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('create_ticket')
            .setLabel(buttonText)
            .setStyle(ButtonStyle.Primary)
            .setEmoji(buttonEmoji)
        );

      // Send ticket panel
      await channel.send({ 
        embeds: [ticketEmbed], 
        components: [ticketButton] 
      });

      // Success response
      const successEmbed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('✅ Ticket System Setup Complete!')
        .setDescription(`Ticket panel has been successfully setup in ${channel}`)
        .addFields(
          { 
            name: '📊 Setup Details', 
            value: `**Channel:** ${channel}\n**Staff Role:** ${staffRole}\n**Button Text:** ${buttonText}`, 
            inline: false 
          },
          { 
            name: '🔧 Next Steps', 
            value: 'Users can now click the button to create tickets. Make sure staff members have access to manage tickets.', 
            inline: false 
          }
        )
        .setFooter({ text: 'Ticket system is now active!' })
        .setTimestamp();

      await interaction.reply({ 
        embeds: [successEmbed],
        ephemeral: true 
      });

    } catch (error) {
      console.error('Ticket setup error:', error);
      await interaction.reply({ 
        content: '❌ Failed to setup ticket system! Check my permissions.', 
        ephemeral: true 
      });
    }
  },
};