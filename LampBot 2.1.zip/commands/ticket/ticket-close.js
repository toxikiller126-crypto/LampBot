const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('ticket-close').setDescription('Close ticket'),
  async execute(interaction) {
    // reply with a button that will close channel when pressed
    await interaction.reply({ content: 'Ticket closed.', ephemeral: true });
    if (interaction.channel) {
      try { await interaction.channel.delete(); } catch(e) {}
    }
  }
};