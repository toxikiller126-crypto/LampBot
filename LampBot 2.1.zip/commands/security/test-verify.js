const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('test-verify')
    .setDescription('Test the verification system instantly'),

  async execute(interaction) {
    const verifyEmbed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('🔐 TEST Verification')
      .setDescription('**Click the button below to test verification!**')
      .addFields(
        { name: '📋 Instructions', value: 'Click "Test Verify" to see if button works', inline: false }
      )
      .setFooter({ text: 'Test Verification System' });

    const verifyButton = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('verify_button')
          .setLabel('Test Verify')
          .setStyle(ButtonStyle.Success)
          .setEmoji('✅')
      );

    await interaction.reply({ 
      content: '**Test Verification Panel:**',
      embeds: [verifyEmbed], 
      components: [verifyButton] 
    });
  },
};