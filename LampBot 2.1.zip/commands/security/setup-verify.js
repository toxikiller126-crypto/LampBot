const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup-verify')
    .setDescription('Setup verification system with working buttons')
    .addChannelOption(option =>
      option.setName('channel')
        .setDescription('Channel where verification will be sent')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true))
    .addRoleOption(option =>
      option.setName('role')
        .setDescription('Role to give after verification')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('title')
        .setDescription('Embed title')
        .setRequired(false))
    .addStringOption(option =>
      option.setName('description')
        .setDescription('Embed description')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    const role = interaction.options.getRole('role');
    const customTitle = interaction.options.getString('title') || '🔐 Verification Required';
    const customDescription = interaction.options.getString('description') || 'Click the button below to verify yourself and get access to the server!';

    // Check permissions
    if (!channel.permissionsFor(interaction.guild.members.me).has(['ViewChannel', 'SendMessages', 'EmbedLinks'])) {
      return interaction.reply({ 
        content: '❌ I don\'t have permission to send messages/embeds in that channel!', 
        ephemeral: true 
      });
    }

    if (!interaction.guild.members.me.roles.highest.comparePositionTo(role)) {
      return interaction.reply({ 
        content: '❌ I cannot assign that role! Make sure my role is above the verification role.', 
        ephemeral: true 
      });
    }

    try {
      // Create verification embed
      const verifyEmbed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle(customTitle)
        .setDescription(customDescription)
        .addFields(
          { 
            name: '📋 How to Verify', 
            value: '1. Click the **"Verify Now"** button below\n2. You will receive the verified role automatically\n3. Get access to all server channels', 
            inline: false 
          },
          { 
            name: '🎯 You Will Receive', 
            value: `${role}`, 
            inline: true 
          }
        )
        .setFooter({ text: `${interaction.guild.name} • Verification System` })
        .setTimestamp();

      // Create verification button
      const verifyButton = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('verify_button')
            .setLabel('Verify Now')
            .setStyle(ButtonStyle.Success)
            .setEmoji('✅')
        );

      // Send verification message
      await channel.send({ 
        embeds: [verifyEmbed], 
        components: [verifyButton] 
      });

      // Success response
      const successEmbed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('✅ Verification System Setup Complete!')
        .setDescription(`Verification has been successfully setup in ${channel}`)
        .addFields(
          { name: '📊 Setup Details', value: `**Channel:** ${channel}\n**Role:** ${role}`, inline: false },
          { name: '🔧 Next Steps', value: 'Users can now click the verify button to get the role.', inline: false }
        )
        .setFooter({ text: 'Verification system is now active!' })
        .setTimestamp();

      await interaction.reply({ 
        embeds: [successEmbed],
        ephemeral: true 
      });

    } catch (error) {
      console.error('Verification setup error:', error);
      await interaction.reply({ 
        content: '❌ Failed to setup verification system! Check my permissions.', 
        ephemeral: true 
      });
    }
  },
};