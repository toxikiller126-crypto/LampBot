const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('banlist').setDescription('Show banned users (recent)'),
  async execute(interaction) {
    const bans = await interaction.guild.bans.fetch().catch(()=>null);
    if (!bans) return interaction.reply({ content: 'Could not fetch bans.' });
    const list = bans.map(b=>`${b.user.tag}`).slice(0,50).join('\n') || 'No bans';
    interaction.reply({ content: `Banned users:\n${list}` });
  }
};