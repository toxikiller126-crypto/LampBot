const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('Show warnings for a user')
    .addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const db = JSON.parse(require('fs').readFileSync('./database/warns.json','utf8'));
    const warns = db[user.id] || [];
    if (!warns.length) return interaction.reply({ content: 'No warnings.' });
    const lines = warns.map((w,i)=>`${i+1}. By <@${w.moderator}>: ${w.reason} (${new Date(w.date).toLocaleString()})`).join('\n');
    interaction.reply({ content: `Warnings for ${user.tag}:\n${lines}` });
  }
};