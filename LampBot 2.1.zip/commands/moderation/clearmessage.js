const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('clearmessage').setDescription('Delete recent messages').addIntegerOption(o=>o.setName('amount').setDescription('Amount').setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    const fetched = await interaction.channel.messages.fetch({ limit: amount }).catch(()=>null);
    if (!fetched) return interaction.reply({ content: 'Failed to fetch messages.', ephemeral: true });
    for (const msg of fetched.values()) { try { await msg.delete(); } catch(e){} }
    interaction.reply({ content: `Deleted ${fetched.size} messages.`, ephemeral: true });
  }
};