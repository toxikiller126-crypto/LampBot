const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('lock').setDescription('Lock a channel').addChannelOption(o=>o.setName('channel').setDescription('Channel').setRequired(false)).setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    const perms = [
      'SendMessages','SendMessagesInThreads','CreatePublicThreads','CreatePrivateThreads'
    ];
    await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, { SendMessages: false, SendMessagesInThreads: false, CreatePublicThreads: false, CreatePrivateThreads: false }).catch(()=>{});
    interaction.reply({ content: `Locked ${channel}.` });
  }
};