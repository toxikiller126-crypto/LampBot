const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout a user (mute)')
    .addUserOption(o=>o.setName('user').setDescription('User to timeout').setRequired(true))
    .addStringOption(o=>o.setName('duration').setDescription('Duration like 10m, 1h').setRequired(true))
    .addStringOption(o=>o.setName('reason').setDescription('Reason').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const dur = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') || 'No reason';
    const ms = (()=>{ try{
      const n = parseInt(dur.slice(0,-1)); const unit=dur.slice(-1);
      if (unit==='s') return n*1000;
      if (unit==='m') return n*60000;
      if (unit==='h') return n*3600000;
      return parseInt(dur);
    }catch(e){return null}})();
    if (!ms) return interaction.reply({ content: 'Invalid duration format. Use 10m, 1h etc.', ephemeral: true });
    const member = await interaction.guild.members.fetch(user.id).catch(()=>null);
    if (!member) return interaction.reply({ content: 'Member not found.', ephemeral: true });
    await member.timeout(ms, reason).catch(()=>{});
    interaction.reply({ content: `${user.tag} was timed out for ${dur}. Reason: ${reason}` });
  }
};