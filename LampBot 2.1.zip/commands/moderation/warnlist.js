const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
module.exports = {
  data: new SlashCommandBuilder().setName('warnlist').setDescription('List all warned users'),
  async execute(interaction) {
    const db = JSON.parse(fs.readFileSync('./database/warns.json','utf8'));
    const ids = Object.keys(db);
    if (!ids.length) return interaction.reply({ content: 'No warned users.'});
    const out = ids.map(id=>`<@${id}> — ${db[id].length} warns`).join('\n');
    interaction.reply({ content: out });
  }
};