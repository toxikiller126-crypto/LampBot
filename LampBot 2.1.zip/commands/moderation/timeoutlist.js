const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('timeoutlist').setDescription('Show timeouts (not stored)'),
  async execute(interaction) {
    interaction.reply({ content: 'Timeouts are not stored persistently. This command is a placeholder.' });
  }
};