const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('kicklist').setDescription('Show recent kicks (not stored)'),
  async execute(interaction) {
    interaction.reply({ content: 'Discord does not expose a kicks list. Consider storing kicks in your own DB.' });
  }
};