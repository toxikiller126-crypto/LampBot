const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a user')
    .addUserOption(o=>o.setName('user').setDescription('User to warn').setRequired(true))
    .addStringOption(o=>o.setName('reason').setDescription('Reason').setRequired(false)),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason';
    const dbPath = './database/warns.json';
    const db = JSON.parse(fs.readFileSync(dbPath,'utf8'));
    db[user.id] = db[user.id] || [];
    db[user.id].push({ moderator: interaction.user.id, reason, date: Date.now() });
    fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
    interaction.reply({ content: `${user.tag} warned. Reason: ${reason}` });
  }
};