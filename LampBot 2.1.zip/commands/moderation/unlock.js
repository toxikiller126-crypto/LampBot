const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('unlock').setDescription('Unlock a channel').addChannelOption(o=>o.setName('channel').setDescription('Channel').setRequired(false)).setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, { SendMessages: null, SendMessagesInThreads: null, CreatePublicThreads: null, CreatePrivateThreads: null }).catch(()=>{});
    interaction.reply({ content: `Unlocked ${channel}.` });
  }
};