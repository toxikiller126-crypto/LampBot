const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('sync-commands')
    .setDescription('Sync all commands with Discord (Owner Only)'),
    
  async execute(interaction) {
    // Check if user is bot owner
    if (interaction.user.id !== 'YOUR_USER_ID_HERE') {
      return interaction.reply({ 
        content: '❌ Only bot owner can use this command!', 
        ephemeral: true 
      });
    }

    await interaction.deferReply({ ephemeral: true });
    
    try {
      const commands = [];
      const commandFolders = require('fs').readdirSync('./commands');

      for (const folder of commandFolders) {
        const commandFiles = require('fs').readdirSync(`./commands/${folder}`).filter(file => file.endsWith('.js'));
        for (const file of commandFiles) {
          const command = require(`../commands/${folder}/${file}`);
          commands.push(command.data.toJSON());
        }
      }

      const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
      
      await rest.put(
        Routes.applicationCommands('1440800524117999666'),
        { body: commands }
      );

      const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('✅ Commands Synced Successfully!')
        .setDescription(`Synced ${commands.length} commands with Discord`)
        .addFields(
          { name: '📊 Total Commands', value: `${commands.length}`, inline: true },
          { name: '🔄 Type', value: 'Global', inline: true }
        )
        .setFooter({ text: 'Commands should appear within 1 hour' });

      await interaction.editReply({ embeds: [embed] });
      
    } catch (error) {
      console.error(error);
      await interaction.editReply({ 
        content: '❌ Failed to sync commands!' 
      });
    }
  },
};