const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('say')
    .setDescription('Make the bot say something')
    .addStringOption(o => o.setName('message').setDescription('Message to send').setRequired(true))
    .addChannelOption(o => o.setName('channel').setDescription('Channel to send in').setRequired(false))
    .addUserOption(o => o.setName('user').setDescription('Mention a user').setRequired(false)),
  async execute(interaction) {
    const msg = interaction.options.getString('message');
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    const user = interaction.options.getUser('user');
    await interaction.reply({ content: 'Message sent.', ephemeral: true });
    channel.send({ content: (user ? `<@${user.id}> ` : '') + msg }).catch(err => {
      interaction.followUp({ content: 'Failed to send message.', ephemeral: true });
    });
  }
};