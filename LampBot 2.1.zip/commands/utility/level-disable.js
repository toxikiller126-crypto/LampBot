const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
module.exports = {
  data: new SlashCommandBuilder().setName('level-disable').setDescription('Disable level system'),
  async execute(interaction) {
    const db = JSON.parse(fs.readFileSync('./database/levels.json','utf8'));
    db.enabled = false;
    fs.writeFileSync('./database/levels.json', JSON.stringify(db, null, 2));
    interaction.reply({ content: 'Level system disabled.' });
  }
};