const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
module.exports = {
  data: new SlashCommandBuilder().setName('level-enable').setDescription('Enable level system'),
  async execute(interaction) {
    const db = JSON.parse(fs.readFileSync('./database/levels.json','utf8'));
    db.enabled = true;
    fs.writeFileSync('./database/levels.json', JSON.stringify(db, null, 2));
    interaction.reply({ content: 'Level system enabled.' });
  }
};