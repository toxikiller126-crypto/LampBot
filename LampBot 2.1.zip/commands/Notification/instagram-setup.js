const { SlashCommandBuilder, EmbedBuilder, ChannelType, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('instagram-setup')
    .setDescription('Setup Instagram account notifications')
    .addChannelOption(option =>
      option.setName('channel')
        .setDescription('Channel where notifications will be sent')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true))
    .addStringOption(option =>
      option.setName('username')
        .setDescription('Instagram username')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('message')
        .setDescription('Custom notification message')
        .setRequired(false)),

  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    const username = interaction.options.getString('username');
    const customMessage = interaction.options.getString('message') || '📸 **New Instagram Post!**\n@{username} just posted!\n{url}';

    const embed = new EmbedBuilder()
      .setColor(0xE4405F)
      .setTitle('✅ Instagram Notifications Setup!')
      .setDescription(`Instagram notifications configured in ${channel}`)
      .addFields(
        { name: '📷 Username', value: `@${username}`, inline: true },
        { name: '🔔 Channel', value: `${channel}`, inline: true },
        { name: '💬 Message', value: customMessage, inline: false }
      );

    await interaction.reply({ embeds: [embed] });
  },
};