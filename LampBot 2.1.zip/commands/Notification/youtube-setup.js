const { SlashCommandBuilder, EmbedBuilder, ChannelType, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('youtube-setup')
    .setDescription('Setup YouTube channel notifications')
    .addChannelOption(option =>
      option.setName('channel')
        .setDescription('Channel where notifications will be sent')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true))
    .addStringOption(option =>
      option.setName('youtube_id')
        .setDescription('YouTube Channel ID')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('message')
        .setDescription('Custom notification message')
        .setRequired(false)),

  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    const youtubeId = interaction.options.getString('youtube_id');
    const customMessage = interaction.options.getString('message') || '🎥 **New YouTube Video!**\n**{title}**\n{url}';

    const embed = new EmbedBuilder()
      .setColor(0xFF0000)
      .setTitle('✅ YouTube Notifications Setup!')
      .setDescription(`YouTube notifications configured in ${channel}`)
      .addFields(
        { name: '📺 YouTube ID', value: youtubeId, inline: true },
        { name: '🔔 Channel', value: `${channel}`, inline: true },
        { name: '💬 Message', value: customMessage, inline: false }
      );

    await interaction.reply({ embeds: [embed] });
  },
};