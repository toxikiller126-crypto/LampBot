const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('notifications')
    .setDescription('Manage YouTube and Instagram notifications')
    .addSubcommand(subcommand =>
      subcommand
        .setName('list')
        .setDescription('List all active notifications'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('test')
        .setDescription('Test notification system')
        .addStringOption(option =>
          option.setName('platform')
            .setDescription('Platform to test')
            .setRequired(true)
            .addChoices(
              { name: 'YouTube', value: 'youtube' },
              { name: 'Instagram', value: 'instagram' }
            )))
    .addSubcommand(subcommand =>
      subcommand
        .setName('remove')
        .setDescription('Remove a notification')
        .addStringOption(option =>
          option.setName('platform')
            .setDescription('Platform to remove')
            .setRequired(true)
            .addChoices(
              { name: 'YouTube', value: 'youtube' },
              { name: 'Instagram', value: 'instagram' }
            ))),

  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();

    if (subcommand === 'list') {
      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle('🔔 Active Notifications')
        .setDescription('Current notification setups:')
        .addFields(
          { name: '📺 YouTube', value: 'Not configured', inline: true },
          { name: '📸 Instagram', value: 'Not configured', inline: true }
        );

      await interaction.reply({ embeds: [embed] });

    } else if (subcommand === 'test') {
      const platform = interaction.options.getString('platform');

      if (platform === 'youtube') {
        const embed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('🎥 TEST: YouTube Notification')
          .setDescription('This is a test YouTube notification!')
          .addFields(
            { name: '📺 Channel', value: 'Test Channel', inline: true },
            { name: '🎬 Video', value: 'Test Video', inline: true }
          );

        await interaction.reply({ 
          content: '🔔 **YOUTUBE TEST NOTIFICATION**',
          embeds: [embed] 
        });

      } else if (platform === 'instagram') {
        const embed = new EmbedBuilder()
          .setColor(0xE4405F)
          .setTitle('📸 TEST: Instagram Notification')
          .setDescription('This is a test Instagram notification!')
          .addFields(
            { name: '📷 Account', value: '@testuser', inline: true },
            { name: '📝 Type', value: 'Photo', inline: true }
          );

        await interaction.reply({ 
          content: '🔔 **INSTAGRAM TEST NOTIFICATION**',
          embeds: [embed] 
        });
      }

    } else if (subcommand === 'remove') {
      const platform = interaction.options.getString('platform');

      const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('✅ Notification Removed')
        .setDescription(`Removed ${platform} notifications`);

      await interaction.reply({ embeds: [embed] });
    }
  },
};