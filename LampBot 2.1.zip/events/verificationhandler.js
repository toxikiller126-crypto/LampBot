const { Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction) {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'start_verification') {
      try {
        // Simple captcha verification (you can make it more complex)
        const captchaCode = Math.random().toString(36).substring(2, 8).toUpperCase();
        
        const captchaEmbed = new EmbedBuilder()
          .setColor(0xFFA500)
          .setTitle('🔐 Complete Verification')
          .setDescription(`Please type the following code to verify:\n\n**\`${captchaCode}\`**\n\nYou have 60 seconds to complete this.`)
          .setFooter({ text: 'This helps prevent bots from joining' });

        await interaction.reply({ 
          embeds: [captchaEmbed], 
          ephemeral: true 
        });

        // Collect response
        const filter = (m) => m.author.id === interaction.user.id;
        const collector = interaction.channel.createMessageCollector({ 
          filter, 
          time: 60000, 
          max: 1 
        });

        collector.on('collect', async (m) => {
          if (m.content.toUpperCase() === captchaCode) {
            // Verification successful
            try {
              // Find verification role (you might want to store this in a database)
              const verifiedRole = interaction.guild.roles.cache.find(role => 
                role.name === 'Verified' || role.name === 'Member'
              ) || interaction.guild.roles.cache.first();

              await interaction.member.roles.add(verifiedRole);

              const successEmbed = new EmbedBuilder()
                .setColor(0x00FF00)
                .setTitle('✅ Verification Successful!')
                .setDescription(`You have been verified and received the ${verifiedRole} role!\n\nWelcome to **${interaction.guild.name}**! 🎉`)
                .setFooter({ text: 'Enjoy your stay in the server!' });

              await m.reply({ 
                embeds: [successEmbed],
                ephemeral: true 
              });

            } catch (roleError) {
              console.error('Role assignment error:', roleError);
              await m.reply({ 
                content: '❌ Failed to assign verification role! Please contact staff.', 
                ephemeral: true 
              });
            }
          } else {
            await m.reply({ 
              content: '❌ Invalid verification code! Please try again.', 
              ephemeral: true 
            });
          }
        });

        collector.on('end', (collected) => {
          if (collected.size === 0) {
            interaction.followUp({ 
              content: '⏰ Verification timed out! Please try again.', 
              ephemeral: true 
            });
          }
        });

      } catch (error) {
        console.error('Verification error:', error);
        await interaction.reply({ 
          content: '❌ An error occurred during verification!', 
          ephemeral: true 
        });
      }
    }
  },
};