module.exports = {
  name: 'messageCreate',
  async execute(client, message) {
    if (message.author.bot) return;
    // level system simple XP
    const fs = require('fs');
    const db = JSON.parse(fs.readFileSync('./database/levels.json','utf8'));
    if (db.enabled) {
      const id = message.author.id;
      db.users[id] = db.users[id] || { xp: 0, level: 0 };
      db.users[id].xp += 1;
      const next = (db.users[id].level + 1) * 100;
      if (db.users[id].xp >= next) {
        db.users[id].level += 1;
        db.users[id].xp = 0;
        try { message.channel.send(`${message.author}, you leveled up to ${db.users[id].level}!`); } catch(e){}
      }
      fs.writeFileSync('./database/levels.json', JSON.stringify(db, null, 2));
    }
  }
};