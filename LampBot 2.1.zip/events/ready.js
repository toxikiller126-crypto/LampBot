const fs = require('fs');
module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    console.log(`${client.user.tag} is online.`);
    // Set presence
    try {
      const guildCount = client.guilds.cache.size;
      await client.user.setPresence({ activities: [{ name: `Playing ${guildCount} servers` }], status: 'online' });
    } catch (e) {
      console.error(e);
    }

    // Load Minecraft panels and start intervals
    const dbPath = './database/minecraft_panels.json';
    let panels = [];
    try {
      panels = JSON.parse(fs.readFileSync(dbPath, 'utf8') || '[]');
    } catch (e) { panels = []; }

    const util = require('minecraft-server-util');

    async function updatePanel(panel) {
      try {
        const guild = await client.guilds.fetch(panel.guildId).catch(()=>null);
        if (!guild) return;
        const channel = await guild.channels.fetch(panel.channelId).catch(()=>null);
        if (!channel) return;
        const message = await channel.messages.fetch(panel.messageId).catch(()=>null);
        if (!message) return;

        // Try to get server status
        try {
          const status = await util.status(panel.ip, { port: panel.port || 25565, timeout: 5000 });
          const embed = {
            title: `Minecraft Server: ${panel.ip}:${panel.port || 25565}`,
            description: status.motd?.clean || 'No MOTD',
            thumbnail: { url: `https://api.mcsrvstat.us/icon/${panel.ip}:${panel.port || 25565}` },
            fields: [
              { name: 'Status', value: '🟢 Online', inline: true },
              { name: 'Players', value: `${status.onlinePlayers || 0} / ${status.maxPlayers || 'Unknown'}`, inline: true },
              { name: 'Version', value: status.version?.name || 'Unknown', inline: true },
              { name: 'Ping (ms)', value: `${status.roundTripLatency || 'N/A'}`, inline: true }
            ],
            timestamp: new Date()
          };
          await message.edit({ embeds: [embed] }).catch(()=>{});
        } catch (e) {
          const embed = {
            title: `Minecraft Server: ${panel.ip}:${panel.port || 25565}`,
            description: '🔴 Offline or unreachable',
            fields: [{ name: 'Status', value: '🔴 Offline or could not reach server' }],
            timestamp: new Date()
          };
          await message.edit({ embeds: [embed] }).catch(()=>{});
        }
      } catch (e) {
        // ignore per-panel errors
      }
    }

    // Start intervals
    for (const panel of panels) {
      const interval = Math.max(10, panel.intervalSec || 30) * 1000;
      // Immediate update
      updatePanel(panel);
      // Set interval and attach to client so it can be cleared if needed
      const iv = setInterval(()=>updatePanel(panel), interval);
      if (!client._mcIntervals) client._mcIntervals = [];
      client._mcIntervals.push(iv);
    }
    console.log(`Loaded ${panels.length} Minecraft panel(s).`);
  }
};