const fs = require('fs');
module.exports = {
  name: 'guildMemberRemove',
  async execute(client, member) {
    try {
      const leave = JSON.parse(fs.readFileSync('./database/leave.json','utf8'));
      if (leave.channel) {
        const ch = member.guild.channels.cache.get(leave.channel);
        if (ch) ch.send({ content: leave.message.replace('{user}', `${member.user.tag}`).replace('{guild}', member.guild.name) }).catch(()=>{});
      }
    } catch(e){}
  }
};