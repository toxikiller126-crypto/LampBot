const fs = require('fs');
module.exports = {
  name: 'guildMemberAdd',
  async execute(client, member) {
    // autorole
    try {
      const ar = JSON.parse(fs.readFileSync('./database/autorole.json','utf8'));
      if (ar.roleId) {
        const role = member.guild.roles.cache.get(ar.roleId);
        if (role) await member.roles.add(role).catch(()=>{});
      }
    } catch(e){}
    // welcome
    try {
      const welcome = JSON.parse(fs.readFileSync('./database/welcome.json','utf8'));
      if (welcome.channel) {
        const ch = member.guild.channels.cache.get(welcome.channel);
        if (ch) ch.send({ content: welcome.message.replace('{user}', `<@${member.id}>`).replace('{guild}', member.guild.name) }).catch(()=>{});
      }
    } catch(e){}
  }
};