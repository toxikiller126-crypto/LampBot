const fs = require('fs');
module.exports = {
  name: 'interactionCreate',
  async execute(client, interaction) {
    if (interaction.isChatInputCommand()) {
      const cmd = client.commands.get(interaction.commandName);
      if (!cmd) return interaction.reply({ content: 'Command not found.', ephemeral: true });
      try {
        await cmd.execute(interaction, client);
      } catch (err) {
        console.error(err);
        if (interaction.replied || interaction.deferred) {
          interaction.followUp({ content: 'There was an error executing this command.', ephemeral: true });
        } else {
          interaction.reply({ content: 'There was an error executing this command.', ephemeral: true });
        }
      }
    } else if (interaction.isButton()) {
      // Basic ticket button handling
      const custom = interaction.customId;
      if (custom === 'ticket_open') {
        const dbPath = './database/tickets.json';
        const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
        const channel = await interaction.guild.channels.create({
          name: `ticket-${interaction.user.username}`.slice(0, 90),
          type: 0, // GUILD_TEXT
          permissionOverwrites: [
            { id: interaction.guild.roles.everyone.id, deny: ['ViewChannel'] },
            { id: interaction.user.id, allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory'] }
          ]
        });
        db.panels.push({ user: interaction.user.id, channel: channel.id });
        fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
        await interaction.reply({ content: `Ticket created: ${channel}`, ephemeral: true });
      } else if (custom === 'ticket_close') {
        // close current channel if ticket present
        if (!interaction.channel) return interaction.reply({ content: 'No channel.', ephemeral: true });
        await interaction.reply({ content: 'Closing this ticket...', ephemeral: true });
        setTimeout(() => interaction.channel.delete().catch(()=>{}), 3000);
      }
    }
  }
};