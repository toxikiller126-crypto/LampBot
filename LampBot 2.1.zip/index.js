const { Client, GatewayIntentBits, ActivityType, Collection, REST, Routes, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

// Load config
let token, clientId;
try {
  const config = require('./config.js');
  token = config.token;
  clientId = config.clientId;
} catch (error) {
  console.error('❌ config.js not found or invalid!');
  token = process.env.DISCORD_TOKEN;
  clientId = "1440800524117999666";
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildMessageReactions,
  ]
});

// Global collections
client.commands = new Collection();
client.cooldowns = new Collection();

// ✅ LOAD ALL COMMANDS PROPERLY
async function loadCommands() {
  console.log('📂 Loading commands...');
  
  const commandsPath = path.join(__dirname, 'commands');
  const commandFolders = fs.readdirSync(commandsPath);
  let loadedCount = 0;

  for (const folder of commandFolders) {
    const folderPath = path.join(commandsPath, folder);
    
    if (!fs.statSync(folderPath).isDirectory()) continue;
    
    const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
    
    for (const file of commandFiles) {
      try {
        const filePath = path.join(folderPath, file);
        const command = require(filePath);
        
        if ('data' in command && 'execute' in command) {
          client.commands.set(command.data.name, command);
          console.log(`✅ ${command.data.name}`);
          loadedCount++;
        } else {
          console.log(`❌ ${file} - Missing data/execute`);
        }
      } catch (error) {
        console.log(`❌ ${file} - ${error.message}`);
      }
    }
  }
  
  console.log(`📊 Loaded ${loadedCount} commands`);
  return loadedCount;
}

// ✅ REGISTER COMMANDS WITH DISCORD
async function registerCommands() {
  try {
    const commands = [];
    
    client.commands.forEach(command => {
      commands.push(command.data.toJSON());
    });

    const rest = new REST({ version: '10' }).setToken(token);
    
    console.log('🔄 Registering commands globally...');
    
    const data = await rest.put(
      Routes.applicationCommands(clientId),
      { body: commands }
    );
    
    console.log(`🎉 Successfully registered ${data.length} commands!`);
    console.log('📋 Commands:', data.map(cmd => cmd.name).join(', '));
    
    return data.length;
  } catch (error) {
    console.error('❌ Command registration failed:', error);
    return 0;
  }
}

// ✅ UPDATE BOT STATUS
function updateBotStatus() {
  if (!client.user) return;
  
  const serverCount = client.guilds.cache.size;
  const memberCount = client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0);
  
  const activities = [
    `${serverCount} servers | /help`,
    `${memberCount.toLocaleString()} users`,
    `LampBot 2.1 | /help`
  ];
  
  const randomActivity = activities[Math.floor(Math.random() * activities.length)];
  
  client.user.setPresence({
    status: 'online',
    activities: [{
      name: randomActivity,
      type: ActivityType.Watching
    }]
  });
}

// ✅ BOT READY EVENT
client.once('clientReady', async () => {
  console.log(`\n🎉 ${client.user.tag} is online!`);
  console.log(`📊 Serving ${client.guilds.cache.size} servers`);
  console.log(`👥 ${client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0)} total users\n`);
  
  // Load and register commands
  const loadedCount = await loadCommands();
  const registeredCount = await registerCommands();
  
  // Set initial status
  updateBotStatus();
  
  // Update status every 2 minutes
  setInterval(updateBotStatus, 120000);
  
  console.log(`\n🚀 Bot is fully operational!`);
  console.log(`💾 Commands: ${loadedCount} loaded, ${registeredCount} registered`);
  console.log(`⏰ Status updates every 2 minutes\n`);
});

// ✅ SLASH COMMAND HANDLER
client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);

  if (!command) {
    return interaction.reply({ 
      content: '❌ Command not found!', 
      ephemeral: true 
    }).catch(console.error);
  }

  try {
    console.log(`⚡ ${interaction.user.tag} used /${interaction.commandName}`);
    await command.execute(interaction);
  } catch (error) {
    console.error(`❌ Error in /${interaction.commandName}:`, error);
    
    const errorEmbed = new EmbedBuilder()
      .setColor(0xFF0000)
      .setTitle('❌ Command Error')
      .setDescription('There was an error executing this command!')
      .addFields(
        { name: 'Command', value: `/${interaction.commandName}`, inline: true },
        { name: 'Error', value: error.message.substring(0, 100), inline: true }
      );

    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ 
        embeds: [errorEmbed], 
        ephemeral: true 
      }).catch(console.error);
    } else {
      await interaction.reply({ 
        embeds: [errorEmbed], 
        ephemeral: true 
      }).catch(console.error);
    }
  }
});

// ✅ BUTTON INTERACTION HANDLER
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;

  console.log(`🔘 Button clicked: ${interaction.customId} by ${interaction.user.tag}`);

  try {
    // VERIFICATION BUTTON
    if (interaction.customId === 'verify_button') {
      await interaction.deferReply({ ephemeral: true });

      // Find verification role
      const verifiedRole = interaction.guild.roles.cache.find(role => 
        role.name.toLowerCase().includes('verified') || 
        role.name.toLowerCase().includes('member') ||
        role.name === '✅ Verified' ||
        role.name === 'Member'
      );

      if (!verifiedRole) {
        return await interaction.editReply({ 
          content: '❌ Verification role not found! Please contact staff to setup a "Verified" or "Member" role.' 
        });
      }

      // Check if user already has role
      if (interaction.member.roles.cache.has(verifiedRole.id)) {
        return await interaction.editReply({ 
          content: '✅ You are already verified!' 
        });
      }

      // Add role to user
      await interaction.member.roles.add(verifiedRole);

      const successEmbed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('✅ Verification Successful!')
        .setDescription(`Welcome to **${interaction.guild.name}**!`)
        .addFields(
          { name: '🎉 Role Added', value: `${verifiedRole}`, inline: true },
          { name: '👤 User', value: interaction.user.toString(), inline: true },
          { name: '📅 Verified At', value: `<t:${Math.floor(Date.now()/1000)}:R>`, inline: true }
        )
        .setThumbnail(interaction.user.displayAvatarURL())
        .setFooter({ text: 'Enjoy your stay! 🎊' });

      await interaction.editReply({ 
        embeds: [successEmbed] 
      });

      console.log(`✅ ${interaction.user.tag} verified successfully`);
    }

    // TICKET BUTTON
    if (interaction.customId === 'create_ticket') {
      await interaction.deferReply({ ephemeral: true });

      const ticketChannel = await interaction.guild.channels.create({
        name: `ticket-${interaction.user.username}`,
        type: 0,
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel']
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory']
          },
          {
            id: client.user.id,
            allow: ['ViewChannel', 'SendMessages', 'ManageChannels']
          }
        ]
      });

      const ticketEmbed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle('🎫 Support Ticket')
        .setDescription(`Hello ${interaction.user}! Thank you for creating a ticket.`)
        .addFields(
          { name: '👤 Created By', value: interaction.user.tag, inline: true },
          { name: '📅 Created At', value: `<t:${Math.floor(Date.now()/1000)}:R>`, inline: true },
          { name: '💬 How to get help', value: 'Please describe your issue and staff will assist you shortly.', inline: false }
        )
        .setFooter({ text: `${interaction.guild.name} Support` });

      await ticketChannel.send({ 
        content: `📨 New ticket from ${interaction.user}`,
        embeds: [ticketEmbed] 
      });

      await interaction.editReply({ 
        content: `✅ Ticket created: ${ticketChannel}` 
      });
    }

  } catch (error) {
    console.error('Button interaction error:', error);
    
    const errorMessage = error.code === 50013 ? 
      '❌ Missing permissions! Please check my role permissions.' : 
      '❌ Action failed! Please try again.';
    
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply({ 
        content: errorMessage 
      }).catch(console.error);
    } else {
      await interaction.reply({ 
        content: errorMessage, 
        ephemeral: true 
      }).catch(console.error);
    }
  }
});

// ✅ GUILD MEMBER EVENTS
client.on('guildMemberAdd', async member => {
  try {
    const channel = member.guild.channels.cache.find(ch => 
      ch.name.includes('welcome') || 
      ch.name.includes('general') ||
      ch.name.includes('join')
    );

    if (channel) {
      const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('🎉 New Member Joined!')
        .setDescription(`Welcome ${member.user} to **${member.guild.name}**!`)
        .addFields(
          { name: '👤 Member', value: member.user.tag, inline: true },
          { name: '👥 Total Members', value: `${member.guild.memberCount}`, inline: true },
          { name: '📅 Account Created', value: `<t:${Math.floor(member.user.createdTimestamp/1000)}:R>`, inline: true }
        )
        .setThumbnail(member.user.displayAvatarURL())
        .setTimestamp();

      await channel.send({ embeds: [embed] });
    }
  } catch (error) {
    console.error('Member join event error:', error);
  }
});

client.on('guildMemberRemove', async member => {
  try {
    const channel = member.guild.channels.cache.find(ch => 
      ch.name.includes('leave') || 
      ch.name.includes('general')
    );

    if (channel) {
      const embed = new EmbedBuilder()
        .setColor(0xFF6B6B)
        .setTitle('😢 Member Left')
        .setDescription(`${member.user.tag} has left the server`)
        .addFields(
          { name: '👤 User', value: member.user.tag, inline: true },
          { name: '👥 Members Left', value: `${member.guild.memberCount}`, inline: true }
        )
        .setTimestamp();

      await channel.send({ embeds: [embed] });
    }
  } catch (error) {
    console.error('Member leave event error:', error);
  }
});

// ✅ ERROR HANDLING
client.on('error', error => {
  console.error('❌ Client error:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Unhandled promise rejection:', reason);
});

process.on('uncaughtException', error => {
  console.error('❌ Uncaught exception:', error);
});

// ✅ LOGIN TO DISCORD
client.login(token).catch(error => {
  console.error('❌ Failed to login:', error);
  console.log('💡 Please check:');
  console.log('   • DISCORD_TOKEN in Replit Secrets');
  console.log('   • Bot token is valid');
  console.log('   • Internet connection');
});