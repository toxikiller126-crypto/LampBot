# Discord.js v14 Bot

Replace config.json token and ids. Run `npm install` then `npm start`.

Made for Replit compatibility.