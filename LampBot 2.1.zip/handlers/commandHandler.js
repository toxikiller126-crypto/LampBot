const fs = require('fs');
const path = require('path');
const { Routes } = require('discord-api-types/v10');
const { REST } = require('@discordjs/rest');
const config = require('../config.json');

module.exports = (client) => {
  const commandsPath = path.join(__dirname, '..', 'commands');
  const commandFiles = [];

  function readCommands(dir) {
    const files = fs.readdirSync(dir, { withFileTypes: true });
    for (const file of files) {
      const full = path.join(dir, file.name);
      if (file.isDirectory()) readCommands(full);
      else if (file.name.endsWith('.js')) commandFiles.push(full);
    }
  }
  readCommands(commandsPath);

  for (const file of commandFiles) {
    const cmd = require(file);
    if (!cmd.data || !cmd.execute) continue;
    client.commands.set(cmd.data.name, cmd);
    client.commandArray.push(cmd.data.toJSON());
  }

  // Register commands to the application (guild if provided for faster updates)
  const rest = new REST({ version: '10' }).setToken(config.token);
  (async () => {
    try {
      if (config.guildId) {
        await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), { body: client.commandArray });
        console.log('Registered guild commands.');
      } else {
        await rest.put(Routes.applicationCommands(config.clientId), { body: client.commandArray });
        console.log('Registered global commands.');
      }
    } catch (e) {
      console.error('Failed to register commands:', e);
    }
  })();
};